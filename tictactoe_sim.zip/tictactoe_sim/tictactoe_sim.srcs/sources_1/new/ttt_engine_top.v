`timescale 1ns / 1ps

module ttt_engine_top (
    input wire clk,
    input wire rst_n,
    input wire i_move_valid,
    input wire [3:0] i_move_pos,
    input wire i_player_id,
    output reg o_move_ready,
    output reg o_illegal_move,
    output reg [1:0] o_game_status,
    output wire [17:0] o_board_flat
);

    reg [1:0] board_matrix [0:8];
    assign o_board_flat = {board_matrix[8], board_matrix[7], board_matrix[6],
                           board_matrix[5], board_matrix[4], board_matrix[3],
                           board_matrix[2], board_matrix[1], board_matrix[0]};

    integer i;

    always @(posedge clk or negedge rst_n) begin
        if (!rst_n) begin
            for (i = 0; i < 9; i = i + 1) board_matrix[i] <= 2'b00;
            o_illegal_move <= 1'b0;
            o_move_ready <= 1'b1;
        end else begin
            o_illegal_move <= 1'b0;
            if (i_move_valid && (i_move_pos < 9)) begin
                if (board_matrix[i_move_pos] == 2'b00) begin
                    board_matrix[i_move_pos] <= (i_player_id == 1'b0) ? 2'b01 : 2'b10;
                end else begin
                    o_illegal_move <= 1'b1;
                end
            end
        end
    end

    always @(*) begin
        o_game_status = 2'b00;
        
        // Rows
        if (board_matrix[0] == 2'b10 && board_matrix[1] == 2'b10 && board_matrix[2] == 2'b10) o_game_status = 2'b10;
        if (board_matrix[3] == 2'b10 && board_matrix[4] == 2'b10 && board_matrix[5] == 2'b10) o_game_status = 2'b10;
        if (board_matrix[6] == 2'b10 && board_matrix[7] == 2'b10 && board_matrix[8] == 2'b10) o_game_status = 2'b10;
        
        // Columns
        if (board_matrix[0] == 2'b10 && board_matrix[3] == 2'b10 && board_matrix[6] == 2'b10) o_game_status = 2'b10;
        if (board_matrix[1] == 2'b10 && board_matrix[4] == 2'b10 && board_matrix[7] == 2'b10) o_game_status = 2'b10;
        if (board_matrix[2] == 2'b10 && board_matrix[5] == 2'b10 && board_matrix[8] == 2'b10) o_game_status = 2'b10;
        
        // Diagonals
        if (board_matrix[0] == 2'b10 && board_matrix[4] == 2'b10 && board_matrix[8] == 2'b10) o_game_status = 2'b10;
        if (board_matrix[2] == 2'b10 && board_matrix[4] == 2'b10 && board_matrix[6] == 2'b10) o_game_status = 2'b10;
    end

endmodule
